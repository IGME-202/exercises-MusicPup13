﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

enum GenMethods
{
	Flat_0,
	Flat_1,
	Ramp,
	Perlin
}

[RequireComponent(typeof(TerrainCollider))]
public class TerrainGeneration : MonoBehaviour
{
	private TerrainData myTerrainData;
	public Vector3 worldSize;
	public int resolution = 129;
	float[,] heightArray;

	[SerializeField]
	GenMethods method;
	[SerializeField]
	[Range(0f, 1f)]
	float raiseFactor = 0.05f;

	// Start is called before the first frame update
	void Start()
	{
		myTerrainData = gameObject.GetComponent<TerrainCollider>().terrainData;
		worldSize = new Vector3(200, 50, 200);
		myTerrainData.size = worldSize;
		myTerrainData.heightmapResolution = resolution;
		heightArray = new float[resolution, resolution];

        // Fill the height array with values!
        // Uncomment the Ramp and Perlin methods to test them out!
        switch (method)
        {
			case GenMethods.Flat_0:
				Flat(0f);
				break;
			case GenMethods.Flat_1:
				Flat(1f);
				break;
			case GenMethods.Perlin:
				Perlin();
				break;
			case GenMethods.Ramp:
				Ramp();
				break;
        }
		

		// Assign values from heightArray into the terrain object's heightmap
		myTerrainData.SetHeights(0, 0, heightArray);
	}


	void Update()
	{

	}

	/// <summary>
	/// Flat()
	/// Assigns heightArray identical values
	/// </summary>
	void Flat(float value)
	{
		// Fill heightArray with 1's
		for (int i = 0; i < resolution; i++)
		{
			for (int j = 0; j < resolution; j++)
			{
				heightArray[i, j] = value;
			}
		}
	}


	/// <summary>
	/// Ramp()
	/// Assigns heightsArray values that form a linear ramp
	/// </summary>
	void Ramp()
	{
		// Fill heightArray with linear values
		for (int i = 0; i < resolution; i++)
		{
			for (int j = 0; j < resolution; j++)
			{
				heightArray[i, j] = (i*raiseFactor) + (j*raiseFactor);
			}
		}

	}

	/// <summary>
	/// Perlin()
	/// Assigns heightsArray values using Perlin noise
	/// </summary>
	void Perlin()
	{
		// Fill heightArray with Perlin-based values
		for (int i = 0; i < resolution; i++)
		{
			for (int j = 0; j < resolution; j++)
			{
				float xCoord = (float)i / resolution;
				float zCoord = (float)j / resolution;
				float pNoise = Mathf.PerlinNoise(xCoord, zCoord);
				heightArray[i, j] = pNoise;
			}
		}

	}
}